The dataset is released for academic use. There are two folders - Train and Test containing the training and testing files respectively.

Each folder has a set of files - two files per process description. The .txt file is the actual text for the process description in text format and the .ann file contains the process annotations. For instance for process 'p1', the text will be contained in p1.txt and annotation in p1.ann.

In order to visualize the data, you can install BRAT from http://brat.nlplab.org/installation.html and upload the data files.
